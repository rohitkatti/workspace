1:"$Sreact.fragment"
2:I[97367,["/workspace/_next/static/chunks/d493362121ff7512.js"],"ViewportBoundary"]
4:I[97367,["/workspace/_next/static/chunks/d493362121ff7512.js"],"MetadataBoundary"]
5:"$Sreact.suspense"
7:I[27201,["/workspace/_next/static/chunks/d493362121ff7512.js"],"IconMark"]
0:{"buildId":"wwnSE9EjNfHIJFgt6HbsL","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false},"head":["$","$1","h",{"children":[null,["$","$L2",null,{"children":"$@3"}],["$","div",null,{"hidden":true,"children":["$","$L4",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":"$@6"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isHeadPartial":false,"staleTime":300}
3:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
6:[["$","link","0",{"rel":"icon","href":"/workspace/favicon.ico?favicon.0b3bf435.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L7","1",{}]]
