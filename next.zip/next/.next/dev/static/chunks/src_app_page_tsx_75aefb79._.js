(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_three_build_three_core_996ef05a.js",
  "static/chunks/node_modules_three_build_three_module_0c59ee63.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_index_6b37bdeb.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_44ed5a0e._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_lucide-react_78492e78.js",
  "static/chunks/node_modules_lucide-react_dist_esm_9cd4cea4._.js",
  "static/chunks/node_modules_61d83ad9._.js",
  "static/chunks/src_657e4a2a._.js"
],
    source: "dynamic"
});
